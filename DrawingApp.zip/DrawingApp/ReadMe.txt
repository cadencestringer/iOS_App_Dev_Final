1)
a. Cady Stringer and James Kistner
b. 2319436 & 2289293
c. cstringer@chapman.edu, jkistner@chapman.edu
d. CPSC 357-01
e. Final Project: Drawing App

2) cStringer-jKistner_Final.zip, which includes:

Views:
ContentView.swift
DrawingWrapper.swift
AddNewDocument.swift

ViewControllers:
DrawingViewController.swift

DataMangers:
CoreDataManager.swift
DrawingManager.swift

Other files:
DrawingAppApp.swift
Persistence.swift
DrawingDocModel.xcdatamodeld
DrawingApp.xcdatamodeld

As well as the built-in Xcode files necessary to build the app, that weren't modified.

3) N/A

4) Sources/resources used:
Images sized using app icon maker: https://appiconmaker.co/Home/Index/73b43a86-e55e-467a-86dc-5684f77854b7
App icon designed using Canva: https://canva.com
https://www.youtube.com/watch?v=s6JYHbtVv0A&list=PLbrKvTeCrFAfoACvHOPWFmDIaKUqBZgEr&index=2
https://www.hackingwithswift.com/articles/118/uiactivityviewcontroller-by-example
https://medium.com/better-programming/an-introduction-to-pencilkit-in-ios-4d40aa62ba5b
https://www.raywenderlich.com/12198216-drawing-with-pencilkit-getting-started#toc-anchor-006
https://medium.com/better-programming/how-to-screenshot-your-ios-apps-ui-in-swift-5c054a9226a5
https://www.hackingwithswift.com/read/13/5/saving-to-the-ios-photo-library
https://jisyed.github.io/blog/2018/using-uuids-in-predicates-to-fetch-core-data-entities/

5) Connect your iPhone to your computer, open the Xcode Project file, and press play to build the app on your iPhone. Tap "Add" to create and name your drawing. Draw and erase to your heart's content. When your drawing is finished, save it to your camera roll via the "Save" button, or share it with friends and family via the "Share" button. Need to take a break? Your drawing will be saved and you can come back later and access any time. Happy drawing!
