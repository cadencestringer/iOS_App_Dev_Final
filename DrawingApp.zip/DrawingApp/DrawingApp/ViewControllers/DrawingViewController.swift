//
//  DrawingViewController.swift
//  DrawingApp
//
//  Created by Cady Stringer on 12/5/20.
//
import UIKit
import PencilKit

class DrawingViewController: UIViewController {
    //creates the canvas view to be used for drawing
    lazy var canvas: PKCanvasView = {
        let v = PKCanvasView()
        //allows finger AND apple pencil drawing
        v.drawingPolicy = .anyInput
        v.minimumZoomScale = 1
        v.maximumZoomScale = 2
        //allows us to set our own constraints instead of automatic ones
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    //gives us all the different pencil/pen options
    lazy var toolPicker: PKToolPicker = {
        let toolPicker = PKToolPicker()
        toolPicker.addObserver(self)
        return toolPicker
    }()
    
    //creates a photo view
    lazy var photoView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    //empty initially
    var drawingData = Data()
    //call this whenever the drawing changes
    var drawingChanged: (Data) -> Void = { _ in }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.addSubview(canvas)
        
        
        //setting our constraints manually
        NSLayoutConstraint.activate([
            canvas.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            canvas.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            canvas.topAnchor.constraint(equalTo: view.topAnchor),
            canvas.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        
        //canvas setup
        toolPicker.setVisible(true, forFirstResponder: canvas)
        toolPicker.addObserver(canvas)
        canvas.delegate = self
        canvas.becomeFirstResponder()
        
        //Share button
        let shareButton = UIButton(type: UIButton.ButtonType.system) as UIButton

        shareButton.frame = CGRect(x:CGFloat(10),y:CGFloat(45),
                              width:CGFloat(55),height:CGFloat(35))
        shareButton.backgroundColor = UIColor.systemBlue
        shareButton.layer.cornerRadius = 5
        shareButton.setTitle("Share", for: UIControl.State.normal)
        shareButton.tintColor = UIColor.white
        shareButton.addTarget(self, action: #selector(DrawingViewController.shareButtonPressed(_:)), for: .touchUpInside)
        shareButton.clipsToBounds = true
        self.view.addSubview(shareButton)
        
        if let drawing = try? PKDrawing(data: drawingData){
            canvas.drawing = drawing
        }
        
        //Clear Drawing button
        let clearButton = UIButton(type: UIButton.ButtonType.system) as UIButton
        
        clearButton.frame = CGRect(x:CGFloat(10), y:CGFloat(5),
                                   width: CGFloat(55), height:CGFloat(35))
        clearButton.backgroundColor = UIColor.systemRed
        clearButton.layer.cornerRadius = 5
        clearButton.setTitle("Clear", for: UIControl.State.normal)
        clearButton.tintColor = UIColor.white
        clearButton.addTarget(self, action: #selector(DrawingViewController.clearButtonPressed(_:)), for: .touchUpInside)
        clearButton.clipsToBounds = true
        self.view.addSubview(clearButton)
    }
    
    @objc func shareButtonPressed(_ sender:UIButton!){
        shareImage()
    }
    
    @objc func clearButtonPressed(_ sender:UIButton!){
        clearImage()
    }
    
    //allows user to share their image via imessage with the caption: "Check out my drawing!"
    @objc func shareImage() {
        let image = canvas.drawing.image(from: canvas.drawing.bounds, scale: 1.0)
        let items: [Any] = ["Check out my drawing!", image]
        let ac = UIActivityViewController(activityItems: items, applicationActivities: nil)
        present(ac, animated: true)
    }
    
    //Clear button functionality
    @objc func clearImage() {
        canvas.drawing = PKDrawing()
    }
    
//    func activityViewController(_ activityViewController: UIActivityViewController, itemForActivityType: UIActivity.ActivityType?) -> Any? {
//        if itemForActivityType == .postToTwitter {
//            return "Check out my #MyAwesomeApp via @twostraws."
//        } else {
//            return "Download MyAwesomeApp from TwoStraws."
//        }
//    }

}

//MARK:- PK Delegates
extension DrawingViewController: PKToolPickerObserver, PKCanvasViewDelegate{
    func canvasViewDrawingDidChange(_ canvasView: PKCanvasView) {
        //converts canvas drawing into data presentation and pass it back wherever we implement the closure call
        drawingChanged(canvasView.drawing.dataRepresentation())
    }
}
