//
//  DrawingDocument.swift
//  DrawingApp
//
//  Created by Cady Stringer on 12/5/20.
//

import Foundation

struct DrawingDocument: Identifiable{
    let id: UUID
    var data: Data
    var name: String
}
