//
//  ContentView.swift
//  DrawingApp
//
//  Created by Cady Stringer on 12/5/20.
//

import SwiftUI

struct ContentView: View {
    @ObservedObject var manager = DrawingManager()
    @State private var addNewShown = false
    
    struct HomeView: View {

        var body: some View {
            VStack {
                List(0..<5) { i in
                    Text("Item - \(i)")
                }
            }
        }

    }
    
    struct SplashView: View {
        
        // 1.
        @State var isActive:Bool = false
        
        var body: some View {
            VStack {
                // 2.
                if self.isActive {
                    // 3.
                    HomeView()
                } else {
                    // 4.
                    Text("Awesome Splash Screen!")
                        .font(Font.largeTitle)
                }
            }
            // 5.
            .onAppear {
                // 6.
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                    // 7.
                    withAnimation {
                        self.isActive = true
                    }
                }
            }
        }
        
    }
    
    var body: some View {
        NavigationView {
            List {
                ForEach(manager.docs) { doc in NavigationLink(destination: DrawingWrapper(manager: manager, id: doc.id),
                    label: { Text(doc.name) })
                }.onDelete(perform: manager.delete)
            }.navigationBarTitleDisplayMode(.inline)
            .navigationBarItems(trailing: Button("Add"){
                self.addNewShown.toggle()
            })

            .sheet(isPresented: $addNewShown, content: {
                AddNewDocument(manager: manager, addShown: $addNewShown)
            })
            
        }
        
    }
}
