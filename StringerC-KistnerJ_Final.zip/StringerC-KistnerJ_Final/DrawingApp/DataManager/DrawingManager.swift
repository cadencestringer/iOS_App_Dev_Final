//
//  DrawingManager.swift
//  DrawingApp
//
//  Created by Cady Stringer & James Kistner on 12/5/20.
//

import SwiftUI

class DrawingManager: ObservableObject{
    @Published var docs: [DrawingDocument]
    
    //connect to core data manager
    init() {
        docs = CoreDataManager.shared.getData()
    }
    
    //updates a drawing based on ID, calls the core data updateData function
    func update(data: Data, for id: UUID){
        if let index = self.docs.firstIndex(where: {$0.id==id}){
            self.docs[index].data = data
            CoreDataManager.shared.updateData(data: self.docs[index])
        }
    }
    
    //gets drawing data given an index, to be used when a user taps on a saved drawing to continue
    func getData(for id: UUID) -> Data {
        if let doc = self.docs.first(where: {$0.id==id}){
            return doc.data
        }
        return Data()
    }
    
    //creates a new drawing when the user taps the "add" button
    func addData(doc: DrawingDocument){
        docs.append(doc)
        CoreDataManager.shared.addData(doc: doc)
    }
    
    //deletes a drawing when the user slides to the left on the drawing name
    func delete(for indexSet: IndexSet){
        for index in indexSet{
            CoreDataManager.shared.deleteData(data: docs[index])
            docs.remove(at: index)
        }
    }
}
