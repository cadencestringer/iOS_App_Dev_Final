//
//  DrawingAppApp.swift
//  DrawingApp
//
//  Created by Cady Stringer & James Kistner on 12/5/20.
//

import SwiftUI

@main
struct DrawingAppApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
