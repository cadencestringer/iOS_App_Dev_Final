//
//  DrawingDocument.swift
//  DrawingApp
//
//  Created by Cady Stringer & James Kistner on 12/5/20.
//

import Foundation

//basic setup for a drawing document includes an ID, the drawing data, and a string that's the drawing's name
struct DrawingDocument: Identifiable{
    let id: UUID
    var data: Data
    var name: String
}
